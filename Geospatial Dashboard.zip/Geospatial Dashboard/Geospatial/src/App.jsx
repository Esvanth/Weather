import React, { useState, useEffect, useRef } from 'react';
import { Trash2, Play, Square, MapPin, ZoomIn, ZoomOut, Globe, Cloud, Thermometer, Droplets, Activity, Layers, Clock, BarChart3 } from 'lucide-react';

// =============================================================================
// DATA CONFIGURATION
// =============================================================================

const dataSources = [
  {
    id: 'temperature',
    name: 'Temperature',
    field: 'temperature_2m',
    unit: '°C',
    icon: <Thermometer className="w-4 h-4" />,
    colorRules: [
      { operator: '<', value: 0, color: '#1e40af' },
      { operator: '>=', value: 0, color: '#3b82f6' },
      { operator: '>=', value: 10, color: '#06b6d4' },
      { operator: '>=', value: 20, color: '#10b981' },
      { operator: '>=', value: 30, color: '#f59e0b' },
      { operator: '>=', value: 40, color: '#ef4444' },
    ]
  },
  {
    id: 'humidity',
    name: 'Humidity',
    field: 'relative_humidity_2m',
    unit: '%',
    icon: <Droplets className="w-4 h-4" />,
    colorRules: [
      { operator: '<', value: 20, color: '#dc2626' },
      { operator: '>=', value: 20, color: '#ea580c' },
      { operator: '>=', value: 40, color: '#f59e0b' },
      { operator: '>=', value: 60, color: '#10b981' },
      { operator: '>=', value: 80, color: '#3b82f6' },
    ]
  },
  {
    id: 'precipitation',
    name: 'Precipitation',
    field: 'precipitation',
    unit: 'mm',
    icon: <Cloud className="w-4 h-4" />,
    colorRules: [
      { operator: '<', value: 0.1, color: '#f3f4f6' },
      { operator: '>=', value: 0.1, color: '#dbeafe' },
      { operator: '>=', value: 1, color: '#93c5fd' },
      { operator: '>=', value: 5, color: '#3b82f6' },
      { operator: '>=', value: 10, color: '#1d4ed8' },
      { operator: '>=', value: 20, color: '#1e40af' },
    ]
  }
];

// =============================================================================
// UTILITY FUNCTIONS
// =============================================================================

const fetchWeatherData = async (lat, lng, startDate, endDate, dataSource) => {
  try {
    const API_URL = 'https://archive-api.open-meteo.com/v1/archive';
    const params = new URLSearchParams({
      latitude: lat.toString(),
      longitude: lng.toString(),
      start_date: startDate,
      end_date: endDate,
      hourly: dataSource,
      timezone: 'auto'
    });

    console.log(`🌤️ Fetching weather data: ${API_URL}?${params.toString()}`);
    
    const response = await fetch(`${API_URL}?${params.toString()}`);
    
    if (!response.ok) {
      throw new Error(`Weather API error: ${response.status} ${response.statusText}`);
    }
    
    const data = await response.json();
    console.log('✅ Weather data received:', data);
    return data;
  } catch (error) {
    console.error('❌ Failed to fetch weather data from Open-Meteo API:', error);
    console.log('🔄 Falling back to mock data for demonstration');
    return generateMockWeatherData(dataSource);
  }
};

const generateMockWeatherData = (dataSource) => {
  const hours = Array.from({ length: 24 * 30 }, (_, i) => i);
  const values = hours.map(() => {
    switch (dataSource) {
      case 'temperature_2m':
        return Math.random() * 45 - 10;
      case 'relative_humidity_2m':
        return Math.random() * 100;
      case 'precipitation':
        return Math.random() * 25;
      default:
        return Math.random() * 50;
    }
  });
  
  return {
    hourly: {
      time: hours.map(h => new Date(Date.now() - (30 * 24 - h) * 60 * 60 * 1000).toISOString()),
      [dataSource]: values
    }
  };
};

const calculatePolygonCentroid = (coordinates) => {
  const x = coordinates.reduce((sum, [lat]) => sum + lat, 0) / coordinates.length;
  const y = coordinates.reduce((sum, [, lng]) => sum + lng, 0) / coordinates.length;
  return [x, y];
};

// =============================================================================
// TIMELINE COMPONENT
// =============================================================================

const Timeline = ({ timelineState, onTimeChange }) => {
  const [sliderValue, setSliderValue] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const intervalRef = useRef(null);

  const now = new Date();
  const startDate = new Date(now.getTime() - 15 * 24 * 60 * 60 * 1000);
  const endDate = new Date(now.getTime() + 15 * 24 * 60 * 60 * 1000);
  const totalHours = Math.floor((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60));

  const handleSliderChange = (value) => {
    setSliderValue(value);
    const selectedTime = new Date(startDate.getTime() + value * 60 * 60 * 1000);
    
    onTimeChange({
      ...timelineState,
      currentTime: selectedTime,
    });
  };

  const togglePlayback = () => {
    if (isPlaying) {
      if (intervalRef.current) clearInterval(intervalRef.current);
      setIsPlaying(false);
    } else {
      setIsPlaying(true);
      intervalRef.current = setInterval(() => {
        setSliderValue(prev => {
          const newValue = prev >= totalHours - 1 ? 0 : prev + 1;
          handleSliderChange(newValue);
          return newValue;
        });
      }, 200);
    }
  };

  const formatDate = (hours) => {
    const date = new Date(startDate.getTime() + hours * 60 * 60 * 1000);
    return {
      date: date.toLocaleDateString(),
      time: date.toLocaleTimeString(),
    };
  };

  const currentFormatted = formatDate(sliderValue);

  return (
    <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-6 shadow-lg border">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-100 rounded-lg">
            <Clock className="w-5 h-5 text-blue-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-800">Timeline Control</h3>
            <p className="text-sm text-gray-600">Navigate through time to see data changes</p>
          </div>
        </div>
        <button
          onClick={togglePlayback}
          className={`px-6 py-2 rounded-lg font-medium transition-all duration-200 flex items-center gap-2 ${
            isPlaying 
              ? 'bg-red-500 hover:bg-red-600 text-white' 
              : 'bg-green-500 hover:bg-green-600 text-white'
          }`}
        >
          {isPlaying ? (
            <>
              <Square className="w-4 h-4" />
              Stop
            </>
          ) : (
            <>
              <Play className="w-4 h-4" />
              Play
            </>
          )}
        </button>
      </div>

      <div className="space-y-4">
        <div className="text-center">
          <div className="text-2xl font-bold text-gray-800">{currentFormatted.date}</div>
          <div className="text-xl text-blue-600 font-medium">{currentFormatted.time}</div>
        </div>
        
        <div className="px-2">
          <input
            type="range"
            min="0"
            max={totalHours}
            step="1"
            value={sliderValue}
            onChange={(e) => handleSliderChange(Number(e.target.value))}
            className="w-full h-3 bg-gradient-to-r from-blue-400 to-indigo-500 rounded-lg appearance-none cursor-pointer"
          />
        </div>
        
        <div className="flex justify-between text-sm text-gray-500">
          <span>{formatDate(0).date}</span>
          <span>{formatDate(totalHours).date}</span>
        </div>
      </div>
    </div>
  );
};

// =============================================================================
// MAP COMPONENT
// =============================================================================

const CustomMap = ({
  mapState,
  onMapStateChange,
  polygons,
  isDrawing,
  currentDrawingPoints,
  onMapClick,
  getPolygonColor
}) => {
  const mapRef = useRef(null);
  const [isDragging, setIsDragging] = useState(false);

  const latLngToPixel = (lat, lng) => {
    const mapWidth = 800;
    const mapHeight = 600;

    const x = ((lng + 180) / 360) * mapWidth;
    const latRad = (lat * Math.PI) / 180;
    const mercN = Math.log(Math.tan(Math.PI / 4 + latRad / 2));
    const y = mapHeight / 2 - (mercN * mapHeight) / (2 * Math.PI);

    return { x, y };
  };

  const pixelToLatLng = (x, y) => {
    const mapWidth = 800;
    const mapHeight = 600;

    const lng = (x / mapWidth) * 360 - 180;
    const mercN = (2 * Math.PI * (mapHeight / 2 - y)) / mapHeight;
    const lat = (2 * Math.atan(Math.exp(mercN)) - Math.PI / 2) * (180 / Math.PI);

    return [lat, lng];
  };

  const handleMouseDown = () => {
    if (isDrawing) return;
    setIsDragging(true);
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleMapClick = (e) => {
    if (!isDrawing) return;

    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const [lat, lng] = pixelToLatLng(x, y);
    onMapClick(lat, lng);
  };

  const zoomIn = () => {
    onMapStateChange({
      ...mapState,
      zoom: Math.min(mapState.zoom + 1, 18)
    });
  };

  const zoomOut = () => {
    onMapStateChange({
      ...mapState,
      zoom: Math.max(mapState.zoom - 1, 1)
    });
  };

  return (
    <div className="relative w-full h-full bg-gradient-to-b from-blue-100 to-blue-200 overflow-hidden rounded-xl shadow-inner">
      {/* Map Controls */}
      <div className="absolute top-6 right-6 z-10 flex flex-col gap-2">
        <button 
          onClick={zoomIn}
          className="bg-white/90 backdrop-blur-sm border border-white/50 hover:bg-white shadow-lg p-3 rounded-lg transition-all"
        >
          <ZoomIn className="w-4 h-4" />
        </button>
        <button 
          onClick={zoomOut}
          className="bg-white/90 backdrop-blur-sm border border-white/50 hover:bg-white shadow-lg p-3 rounded-lg transition-all"
        >
          <ZoomOut className="w-4 h-4" />
        </button>
      </div>

      {/* Map Container */}
      <div
        ref={mapRef}
        className={`w-full h-full relative ${isDrawing ? 'cursor-crosshair' : isDragging ? 'cursor-grabbing' : 'cursor-grab'}`}
        onMouseDown={handleMouseDown}
        onMouseUp={handleMouseUp}
        onClick={handleMapClick}
        style={{
          backgroundImage: `
            radial-gradient(circle at 25% 25%, rgba(59, 130, 246, 0.1) 0%, transparent 50%),
            radial-gradient(circle at 75% 75%, rgba(139, 92, 246, 0.1) 0%, transparent 50%),
            linear-gradient(90deg, rgba(59, 130, 246, 0.05) 1px, transparent 1px),
            linear-gradient(rgba(59, 130, 246, 0.05) 1px, transparent 1px)
          `,
          backgroundSize: '40px 40px, 40px 40px, 20px 20px, 20px 20px'
        }}
      >
        {/* World Map SVG */}
        <svg
          className="absolute inset-0 w-full h-full"
          viewBox="0 0 800 600"
          style={{ pointerEvents: 'none' }}
        >
          <defs>
            <linearGradient id="continent1" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#10b981" stopOpacity="0.2"/>
              <stop offset="100%" stopColor="#059669" stopOpacity="0.3"/>
            </linearGradient>
            <linearGradient id="continent2" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#8b5cf6" stopOpacity="0.2"/>
              <stop offset="100%" stopColor="#7c3aed" stopOpacity="0.3"/>
            </linearGradient>
          </defs>
          
          <path
            d="M 100 200 L 300 180 L 500 200 L 700 220 L 650 350 L 400 380 L 150 360 Z"
            fill="url(#continent1)"
            stroke="#10b981"
            strokeWidth="2"
          />
          <path
            d="M 200 100 L 600 80 L 650 200 L 550 250 L 200 230 Z"
            fill="url(#continent2)"
            stroke="#8b5cf6"
            strokeWidth="2"
          />
        </svg>

        {/* Polygons SVG */}
        <svg className="absolute inset-0 w-full h-full" viewBox="0 0 800 600">
          {polygons.map(polygon => {
            const points = polygon.coordinates
              .map(([lat, lng]) => latLngToPixel(lat, lng))
              .map(({ x, y }) => `${x},${y}`)
              .join(' ');
            
            return (
              <g key={polygon.id}>
                <polygon
                  points={points}
                  fill={getPolygonColor(polygon)}
                  fillOpacity="0.7"
                  stroke="white"
                  strokeWidth="3"
                  filter="drop-shadow(2px 2px 4px rgba(0,0,0,0.2))"
                  className="transition-all duration-300 hover:fill-opacity-90"
                />
                <polygon
                  points={points}
                  fill={getPolygonColor(polygon)}
                  fillOpacity="0.3"
                  stroke={getPolygonColor(polygon)}
                  strokeWidth="2"
                />
              </g>
            );
          })}
          
          {/* Current Drawing Polygon */}
          {currentDrawingPoints.length >= 3 && (
            <polygon
              points={currentDrawingPoints
                .map(([lat, lng]) => latLngToPixel(lat, lng))
                .map(({ x, y }) => `${x},${y}`)
                .join(' ')}
              fill="#3b82f6"
              fillOpacity="0.4"
              stroke="#3b82f6"
              strokeWidth="3"
              strokeDasharray="8,4"
              className="animate-pulse"
            />
          )}
          
          {/* Drawing Points */}
          {currentDrawingPoints.map(([lat, lng], index) => {
            const { x, y } = latLngToPixel(lat, lng);
            return (
              <g key={index}>
                <circle
                  cx={x}
                  cy={y}
                  r="8"
                  fill="#3b82f6"
                  fillOpacity="0.3"
                  className="animate-ping"
                />
                <circle
                  cx={x}
                  cy={y}
                  r="5"
                  fill="#3b82f6"
                  stroke="white"
                  strokeWidth="2"
                />
                <text
                  x={x}
                  y={y - 12}
                  textAnchor="middle"
                  className="text-xs fill-gray-700 font-medium"
                >
                  {index + 1}
                </text>
              </g>
            );
          })}
        </svg>

        {/* Status Overlay */}
        <div className="absolute bottom-6 left-6 bg-white/90 backdrop-blur-md rounded-xl shadow-xl p-4 border border-white/50">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-blue-600" />
              <span className="text-sm font-medium text-gray-700">Map Status</span>
            </div>
            <div className="text-xs text-gray-600 space-y-1">
              <div>Zoom: <span className="font-mono font-medium">{mapState.zoom}</span></div>
              <div>Center: <span className="font-mono">{mapState.center[0].toFixed(2)}, {mapState.center[1].toFixed(2)}</span></div>
              <div className="text-blue-600">Open-Meteo API</div>
            </div>
            {isDrawing && (
              <div className="mt-3 p-2 bg-blue-50 rounded-lg border border-blue-200">
                <div className="text-blue-700 font-medium text-sm mb-1">Drawing Active</div>
                <div className="text-xs text-blue-600">
                  Points: {currentDrawingPoints.length}/12
                </div>
                {currentDrawingPoints.length >= 3 && (
                  <div className="text-xs text-green-600 font-medium">Ready to finish!</div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

// =============================================================================
// DRAWING CONTROLS COMPONENT
// =============================================================================

const DrawingControls = ({ 
  selectedDataSource, 
  setSelectedDataSource, 
  isDrawing, 
  currentDrawingPoints, 
  startDrawing, 
  finishDrawing, 
  cancelDrawing 
}) => {
  return (
    <div className="mb-6 border shadow-lg bg-white rounded-lg border-gray-200">
      <div className="p-4 pb-2 border-b border-gray-100">
        <h3 className="flex items-center gap-2 text-lg font-semibold text-gray-800">
          <Layers className="w-5 h-5 text-blue-600" />
          Drawing Tools
        </h3>
      </div>
      <div className="p-4 space-y-6">
        <div>
          <label className="text-sm font-medium text-gray-700 mb-3 block">Data Source</label>
          <select 
            value={selectedDataSource} 
            onChange={(e) => setSelectedDataSource(e.target.value)}
            className="w-full h-12 px-3 border border-gray-300 bg-white rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-gray-900"
          >
            {dataSources.map(ds => (
              <option key={ds.id} value={ds.id}>
                {ds.name} ({ds.unit})
              </option>
            ))}
          </select>
        </div>
        
        {!isDrawing ? (
          <button 
            onClick={startDrawing} 
            className="w-full h-12 bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white font-medium shadow-lg hover:shadow-xl transition-all duration-200 rounded-lg flex items-center justify-center gap-2"
          >
            <MapPin className="w-5 h-5" />
            Start Drawing Polygon
          </button>
        ) : (
          <div className="space-y-3">
            <button 
              onClick={finishDrawing} 
              disabled={currentDrawingPoints.length < 3}
              className="w-full h-12 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white font-medium shadow-lg disabled:opacity-50 disabled:cursor-not-allowed rounded-lg transition-all"
            >
              ✓ Finish Polygon ({currentDrawingPoints.length} points)
            </button>
            <button 
              onClick={cancelDrawing} 
              className="w-full h-12 border-2 border-red-300 text-red-600 hover:bg-red-50 hover:border-red-400 rounded-lg transition-all font-medium"
            >
              Cancel Drawing
            </button>
          </div>
        )}
        
        {isDrawing && (
          <div className="p-4 bg-blue-50 rounded-xl border-2 border-blue-200">
            <div className="text-sm text-gray-700 space-y-2">
              <div className="flex items-center gap-2 font-medium text-blue-700">
                <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                Drawing Mode Active
              </div>
              <div className="text-xs space-y-1 text-gray-600">
                <p>• Click to add points (3-12 max)</p>
                <p>• Current: <span className="font-medium text-gray-800">{currentDrawingPoints.length}</span> points</p>
                {currentDrawingPoints.length >= 3 && (
                  <p className="text-green-600 font-medium">• Ready to finish!</p>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// =============================================================================
// REGIONS LIST COMPONENT
// =============================================================================

const RegionsList = ({ polygons, getPolygonColor, getCurrentDataValue, deletePolygon, isLoadingData }) => {
  return (
    <div className="mb-6 border shadow-lg bg-white rounded-lg border-gray-200">
      <div className="p-4 pb-2 border-b border-gray-100">
        <h3 className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-purple-600" />
            <span className="text-lg font-semibold text-gray-800">Regions ({polygons.length})</span>
          </div>
          {isLoadingData && (
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce"></div>
              <span className="text-sm text-blue-600">Loading...</span>
            </div>
          )}
        </h3>
      </div>
      <div className="p-4">
        <div className="space-y-3">
          {polygons.length === 0 ? (
            <div className="text-center py-8">
              <Globe className="w-12 h-12 text-gray-400 mx-auto mb-3" />
              <p className="text-gray-600 text-sm font-medium">No regions drawn yet</p>
              <p className="text-gray-500 text-xs">Start drawing to add regions</p>
            </div>
          ) : (
            polygons.map(polygon => {
              const dataSource = dataSources.find(ds => ds.id === polygon.dataSource);
              return (
                <div key={polygon.id} className="group p-4 border-2 border-gray-200 rounded-xl bg-gray-50 hover:bg-white hover:shadow-md hover:border-gray-300 transition-all duration-200">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div 
                        className="w-6 h-6 rounded-lg shadow-sm ring-2 ring-white" 
                        style={{ backgroundColor: getPolygonColor(polygon) }}
                      />
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium text-gray-800">{polygon.name}</span>
                          <span className="text-gray-600">{dataSource?.icon}</span>
                        </div>
                        <div className="text-xs text-gray-600 mb-1">
                          {dataSource?.name}
                        </div>
                        <div className="text-lg font-bold text-gray-900">
                          {getCurrentDataValue(polygon)}
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={() => deletePolygon(polygon.id)}
                      className="opacity-0 group-hover:opacity-100 transition-opacity text-red-500 hover:text-red-700 hover:bg-red-50 p-2 rounded-lg border border-transparent hover:border-red-200"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};

// =============================================================================
// COLOR LEGEND COMPONENT
// =============================================================================

const ColorLegend = ({ selectedDataSource }) => {
  const selectedDataSourceObj = dataSources.find(ds => ds.id === selectedDataSource);

  return (
    <div className="border-0 shadow-lg bg-gradient-to-br from-white to-gray-50/50 rounded-lg">
      <div className="p-4 pb-2">
        <h3 className="flex items-center gap-2 text-lg font-semibold">
          <div className="w-5 h-5 bg-gradient-to-r from-red-400 to-blue-400 rounded"></div>
          Color Legend
        </h3>
      </div>
      <div className="p-4">
        {selectedDataSourceObj && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 mb-3">
              {selectedDataSourceObj.icon}
              <span className="font-medium">{selectedDataSourceObj.name}</span>
              <span className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full">
                {selectedDataSourceObj.unit}
              </span>
            </div>
            <div className="space-y-2">
              {selectedDataSourceObj.colorRules.map((rule, index) => (
                <div key={index} className="flex items-center gap-3 text-sm">
                  <div 
                    className="w-4 h-4 rounded-md shadow-sm ring-1 ring-gray-200" 
                    style={{ backgroundColor: rule.color }}
                  />
                  <span className="font-mono text-gray-700">
                    {rule.operator === '>=' ? '≥' : rule.operator} {rule.value}{selectedDataSourceObj.unit}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// =============================================================================
// MAIN DASHBOARD COMPONENT
// =============================================================================

const GeospatialDashboard = () => {
  // State management
  const [polygons, setPolygons] = useState([]);
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentDrawingPoints, setCurrentDrawingPoints] = useState([]);
  const [selectedDataSource, setSelectedDataSource] = useState(dataSources[0].id);
  const [weatherData, setWeatherData] = useState({});
  const [isLoadingData, setIsLoadingData] = useState(false);
  const [mapState, setMapState] = useState({
    center: [20.5937, 78.9629],
    zoom: 5,
    bounds: [[-90, -180], [90, 180]]
  });
  const [timelineState, setTimelineState] = useState({
    currentTime: new Date(),
    startTime: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000),
    endTime: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000),
    isRange: false
  });

  // Event handlers
  const handleMapClick = (lat, lng) => {
    if (!isDrawing) return;

    const newPoint = [lat, lng];
    const updatedPoints = [...currentDrawingPoints, newPoint];

    if (updatedPoints.length >= 12) {
      completePolygon(updatedPoints);
    } else {
      setCurrentDrawingPoints(updatedPoints);
    }
  };

  const completePolygon = async (coordinates) => {
    if (coordinates.length < 3) return;

    const newPolygon = {
      id: `polygon-${Date.now()}`,
      coordinates,
      dataSource: selectedDataSource,
      color: '#3b82f6',
      name: `Region ${polygons.length + 1}`
    };

    setPolygons([...polygons, newPolygon]);
    setCurrentDrawingPoints([]);
    setIsDrawing(false);

    await fetchPolygonWeatherData(newPolygon);
  };

  const fetchPolygonWeatherData = async (polygon) => {
    setIsLoadingData(true);
    try {
      const [lat, lng] = calculatePolygonCentroid(polygon.coordinates);
      
      console.log(`🎯 Fetching weather data for polygon "${polygon.name}" at coordinates: ${lat.toFixed(4)}, ${lng.toFixed(4)}`);
      
      const startDate = new Date(timelineState.startTime.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
      const endDate = new Date(timelineState.endTime.getTime() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
      
      const dataSource = dataSources.find(ds => ds.id === polygon.dataSource);
      if (!dataSource) {
        console.error('❌ Data source not found:', polygon.dataSource);
        return;
      }
      
      const weatherResponse = await fetchWeatherData(lat, lng, startDate, endDate, dataSource.field);
      
      const polygonWeatherData = {};
      if (weatherResponse.hourly?.time && weatherResponse.hourly[dataSource.field]) {
        weatherResponse.hourly.time.forEach((time, index) => {
          const value = weatherResponse.hourly[dataSource.field][index];
          if (value !== null && value !== undefined) {
            polygonWeatherData[time] = value;
          }
        });

        console.log(`📊 Stored ${Object.keys(polygonWeatherData).length} data points for polygon "${polygon.name}"`);
      }

      setWeatherData(prev => ({
        ...prev,
        [polygon.id]: polygonWeatherData
      }));
    } catch (error) {
      console.error('❌ Failed to fetch weather data for polygon:', polygon.name, error);
    } finally {
      setIsLoadingData(false);
    }
  };

  const startDrawing = () => {
    setIsDrawing(true);
    setCurrentDrawingPoints([]);
  };

  const cancelDrawing = () => {
    setIsDrawing(false);
    setCurrentDrawingPoints([]);
  };

  const finishDrawing = () => {
    if (currentDrawingPoints.length >= 3) {
      completePolygon(currentDrawingPoints);
    }
  };

  const deletePolygon = (id) => {
    setPolygons(polygons.filter(p => p.id !== id));
  };

  const getPolygonColor = (polygon) => {
    const dataSource = dataSources.find(ds => ds.id === polygon.dataSource);
    if (!dataSource) return polygon.color;
    
    const currentTimeISO = timelineState.currentTime.toISOString();
    const polygonData = weatherData[polygon.id];
    
    let currentValue;
    
    if (polygonData && polygonData[currentTimeISO]) {
      currentValue = polygonData[currentTimeISO];
    } else {
      if (polygonData) {
        const availableTimes = Object.keys(polygonData);
        const closestTime = availableTimes.reduce((closest, time) => {
          const timeDiff = Math.abs(new Date(time).getTime() - timelineState.currentTime.getTime());
          const closestDiff = Math.abs(new Date(closest).getTime() - timelineState.currentTime.getTime());
          return timeDiff < closestDiff ? time : closest;
        }, availableTimes[0]);
        
        currentValue = polygonData[closestTime] || 0;
      } else {
        switch (polygon.dataSource) {
          case 'temperature':
            currentValue = Math.random() * 45 - 10;
            break;
          case 'humidity':
            currentValue = Math.random() * 100;
            break;
          case 'precipitation':
            currentValue = Math.random() * 25;
            break;
          default:
            currentValue = Math.random() * 50;
        }
      }
    }
    
    for (let i = dataSource.colorRules.length - 1; i >= 0; i--) {
      const rule = dataSource.colorRules[i];
      if (rule.operator === '>=' && currentValue >= rule.value) return rule.color;
      if (rule.operator === '>' && currentValue > rule.value) return rule.color;
      if (rule.operator === '<=' && currentValue <= rule.value) return rule.color;
      if (rule.operator === '<' && currentValue < rule.value) return rule.color;
    }
    
    return polygon.color;
  };

  const getCurrentDataValue = (polygon) => {
    const dataSource = dataSources.find(ds => ds.id === polygon.dataSource);
    if (!dataSource) return 'N/A';

    const polygonData = weatherData[polygon.id];
    const currentTimeISO = timelineState.currentTime.toISOString();

    if (!polygonData) return 'Loading...';

    let currentValue = polygonData[currentTimeISO] ?? null;

    if (currentValue === null) {
      const availableTimes = Object.keys(polygonData);
      if (availableTimes.length > 0) {
        const closestTime = availableTimes.reduce((closest, time) => {
          const diff = Math.abs(new Date(time).getTime() - timelineState.currentTime.getTime());
          const closestDiff = Math.abs(new Date(closest).getTime() - timelineState.currentTime.getTime());
          return diff < closestDiff ? time : closest;
        }, availableTimes[0]);

        currentValue = polygonData[closestTime] ?? null;
      }
    }

    return currentValue !== null ? `${currentValue.toFixed(1)}${dataSource.unit}` : 'Loading...';
  };

  // Effects
  useEffect(() => {
    const updatePolygonColors = async () => {
      if (polygons.length === 0) return;
      
      console.log('🔄 Timeline changed, updating polygon colors for time:', timelineState.currentTime);
      
      for (const polygon of polygons) {
        const currentTimeISO = timelineState.currentTime.toISOString();
        const polygonData = weatherData[polygon.id];
        
        if (!polygonData || !polygonData[currentTimeISO]) {
          console.log(`🔄 Updating data for polygon ${polygon.name} at time ${currentTimeISO}`);
          await fetchPolygonWeatherData(polygon);
        }
      }
    };
    
    updatePolygonColors();
  }, [timelineState.currentTime]);

  useEffect(() => {
    polygons.forEach(polygon => {
      if (!weatherData[polygon.id]) {
        console.log(`🆕 Fetching initial data for new polygon: ${polygon.name}`);
        fetchPolygonWeatherData(polygon);
      }
    });
  }, [polygons.length]);

  return (
    <div className="flex min-h-screen w-full bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 text-gray-900" style={{ height: '100vh', width: '100vw' }}>
      {/* Sidebar */}
      <div className="w-96 bg-white/95 backdrop-blur-xl shadow-2xl border-r border-gray-200 overflow-y-auto">
        <div className="p-6">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-3 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl shadow-lg">
                <Activity className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-gray-800 to-gray-600 bg-clip-text text-transparent">
                  Geospatial Dashboard
                </h1>
                <p className="text-sm text-gray-600">Weather Data Visualization</p>
              </div>
            </div>
          </div>
          
          {/* Drawing Controls */}
          <DrawingControls 
            selectedDataSource={selectedDataSource}
            setSelectedDataSource={setSelectedDataSource}
            isDrawing={isDrawing}
            currentDrawingPoints={currentDrawingPoints}
            startDrawing={startDrawing}
            finishDrawing={finishDrawing}
            cancelDrawing={cancelDrawing}
          />

          {/* Regions List */}
          <RegionsList 
            polygons={polygons}
            getPolygonColor={getPolygonColor}
            getCurrentDataValue={getCurrentDataValue}
            deletePolygon={deletePolygon}
            isLoadingData={isLoadingData}
          />

          {/* Color Legend */}
          <ColorLegend selectedDataSource={selectedDataSource} />
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Timeline */}
        <div className="p-6">
          <Timeline 
            timelineState={timelineState}
            onTimeChange={setTimelineState}
          />
        </div>

        {/* Map */}
        <div className="flex-1 p-6 pt-0">
          <CustomMap
            mapState={mapState}
            onMapStateChange={setMapState}
            polygons={polygons}
            isDrawing={isDrawing}
            currentDrawingPoints={currentDrawingPoints}
            onMapClick={handleMapClick}
            getPolygonColor={getPolygonColor}
          />
        </div>
      </div>
    </div>
  );
};

export default GeospatialDashboard;